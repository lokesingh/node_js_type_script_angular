import {
    Schema
  } from 'mongoose';
  import mongoose from 'mongoose';
  
  export const Information = new Schema({
    id: { type: mongoose.Schema.Types.ObjectId, required: false },
    name: String,
    image: String,
    price: Number
  });

const information = mongoose.model("information", Information);
export default information;