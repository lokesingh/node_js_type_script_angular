
import information from '../model/information';

export const getInformationList = async (req:any, res:any) => {
    information.find((err: any, result: any) => {
        if (err) {
            console.log(err);
            var  response={ status: 500, msg: 'Internale server error' }
            return   res.send(response)
        } else {
        console.log(JSON.stringify(result))
          res.send(result);
        }
      });
  };

  export const createInformation = async (req:any, res:any) => {
    
    console.log(JSON.stringify( req.body))
     let infor = new information(req.body);
     infor.save((err:any, result:any) => {
        if (err) {
            console.log(err);
			   var  response={ status: 500, msg: 'Internale server error' }
			   return   res.send(response)
          } else {
          console.log(JSON.stringify(result))
            res.send(result);
          }
    });
  };

export const updateInformation = async (req:any, res:any) => {
    let id = req.body.id
    information.findOneAndUpdate({ _id:id },{ $set: req.body} , (err, getinformation)=> {
        if (err) {
            console.log(err);
			   var  response={ status: 500, msg: 'Internale server error' }
			   return   res.send(response)
        } 
        // success data send
        res.send(getinformation);
    })
};

export const getByIdInformation = async (req:any, res:any) => {
    let id = req.query.id
    information.find({_id:id},(err, getinformation)=>{
        if (err) {
            console.log(err);
			   var  response={ status: 500, msg: 'Internale server error' }
			   return   res.send(response)
        } 
        // success data send
        res.send(getinformation);
    })
};

export const deleteInformation = async (req:any, res:any) => {
    let id = req.query.id
    information.find({_id:id},(err, getinformation)=>{
        if (err) {
            console.log(err);
            var  response={ status: 500, msg: 'Internale server error' }
            return   res.send(response)
        } 
        // success data send
        res.send(getinformation);
    })
};