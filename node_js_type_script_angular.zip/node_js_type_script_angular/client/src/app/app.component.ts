import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  informationListData ;
  formData = {name:'',price:''};
  constructor(private http: HttpClient, private formBuilder: FormBuilder, private router: Router) { }
  ngOnInit(): void {
    this.getAllInformation();
  }

  getAllInformation() {
    let url = 'http://localhost:8000/product/api/getInformationList';
    return this.http.get(url).subscribe(response => {
      if (response) {
        this.informationListData = response;
        // console.log('this.usersList', response);
      }
    }, error => {
      console.log('error.msg', error.error)
      // this.toastr.info(error.error.msg, 'Information');
      // this.router.navigate(['']);
    });
  }
  addinformation() {

    var url = "http://localhost:8000/product/api/createInformation";
    console.log('this.formData',this.formData)
    return this.http.post(url, this.formData)
      .subscribe(response => {
        console.log('response', response)
        if (response) {
          this.getAllInformation()
          //  localStorage.setItem("userName",response.user.firstName);

          window.location.reload();
        } else {
          window.location.reload();
        }
      }, error => {
        console.log('error.msg', error.error)
        // this.router.navigate(['']);
      });

  }

  getinformation(id) {
    alert(id)
    let url = `http://localhost:8000/product/api/getByIdInformation?id=${id}`;
    return this.http.get(url).subscribe(response => {
      if (response) {
       // this.formData.name = response.name;
       // this.formData.price = response.price;
         console.log('this.usersList', response);
      }
    }, error => {
      console.log('error.msg', error.error)
    });
  }

}
